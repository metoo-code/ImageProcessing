from flask import Flask, render_template
from flask_socketio import SocketIO
import cv2
import base64
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app)

video_path = "video/CAR.mp4"
cap = cv2.VideoCapture(video_path)
slot_empty = [True] * 10

def detect_car(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blur, 100, 200)
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    num_boxes = 6
    box_width = 120
    box_height = 240
    gap = 80
    empty_slots = 0

    for i in range(num_boxes):
        x = i * (box_width + gap) + 50
        y = 360
        if slot_empty[i]:
            cv2.rectangle(frame, (x, y), (x + box_width, y + box_height), (0, 255, 0), 2)
            empty_slots += 1
        else:
            cv2.rectangle(frame, (x, y), (x + box_width, y + box_height), (0, 0, 255), 2)
        cv2.putText(frame, f"{i+1}", (x + 10, y + 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

    for contour in contours:
        for i in range(num_boxes):
            x = i * (box_width + gap) + 50
            y = 360
            x_contour, y_contour, w_contour, h_contour = cv2.boundingRect(contour)
            if x_contour > x and x_contour + w_contour < x + box_width and y_contour > y and y_contour + h_contour < y + box_height:
                if slot_empty[i]:
                    slot_empty[i] = False
                    empty_slots -= 1
                    break

    cv2.putText(frame, f"Free: {empty_slots}", (50, 70), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 0), 2)
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cv2.putText(frame, f"Date & Time: {current_time}", (50, 120), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

    return frame

def generate_frames():
    while True:
        success, frame = cap.read()
        if not success:
            break
        frame = detect_car(frame)
        _, buffer = cv2.imencode('.jpg', frame)
        frame_bytes = base64.b64encode(buffer).decode('utf-8')
        socketio.emit('frame', frame_bytes)
        socketio.sleep(0.1)  # Adjust the sleep time to control the frame rate

@socketio.on('connect')
def handle_connect():
    print('Client connected')
    socketio.start_background_task(target=generate_frames)

@socketio.on('disconnect')
def handle_disconnect():
    print('Client disconnected')

@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5001, debug=True)
