import cv2
import base64
from datetime import datetime
import firebase_admin
from firebase_admin import credentials, db
from ultralytics import YOLO
from flask import Flask, render_template
from flask_socketio import SocketIO

app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, async_mode='eventlet')

# Open webcam or video
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Error: Could not open webcam.")
    exit()

# Initialize Firebase
try:
    cred = credentials.Certificate('C:/Users/acer/py/app/path/cardata-5ff57-firebase-adminsdk-ba8a0-5f85c53755.json')
    firebase_admin.initialize_app(cred, {
        'databaseURL': 'https://cardata-5ff57-default-rtdb.firebaseio.com'
    })
except Exception as e:
    print(f"Error initializing Firebase: {e}")
    exit()

# Initialize slot_empty list
num_boxes = 12
slot_empty = [True] * num_boxes

# Load YOLO model
model = YOLO('yolov8n.pt')

def detect_yolo(frame):
    global slot_empty

    # Perform YOLO detection
    results = model(frame)

    if results is not None and hasattr(results, 'xyxy'):
        detected_objects = results.xyxy[0].cpu().numpy()
    else:
        detected_objects = []

    box_width = 80
    box_height = 130
    gap = 5
    num_boxes = len(slot_empty)

    for i in range(num_boxes):
        if i < 6:
            x = i * (box_width + gap) + 130
            y = 10
        else:
            x = (i - 6) * (box_width + gap) + 130
            y = 195 + gap

        slot_empty[i] = True

        for obj in detected_objects:
            x1, y1, x2, y2, conf, cls = obj
            if int(cls) in [0, 1, 2, 16, 18, 20]:  # Include class IDs for circle and rectangle
                if (x < x1 < x + box_width and y < y1 < y + box_height and
                        x < x2 < x + box_width and y < y2 < y + box_height):
                    slot_empty[i] = False
                    object_name = "Person" if int(cls) == 0 else "Car" if int(cls) == 2 else "Pet" if int(cls) == 16 else "Circle" if int(cls) == 18 else "Rectangle" if int(cls) == 20 else "Unknown"
                    cv2.putText(frame, object_name, (x + 10, y + 60), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
                    break

def detect_contours(frame):
    global slot_empty

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blur, 100, 200)
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    box_width = 80
    box_height = 130
    gap = 5
    num_boxes = len(slot_empty)

    for i in range(num_boxes):
        if i < 6:
            x = i * (box_width + gap) + 130
            y = 10
        else:
            x = (i - 6) * (box_width + gap) + 130
            y = 195 + box_height + gap

        slot_empty[i] = True

        for contour in contours:
            x_contour, y_contour, w_contour, h_contour = cv2.boundingRect(contour)

            if (x < x_contour < x + box_width and y < y_contour < y + box_height and
                    x < x_contour + w_contour < x + box_width and y < y_contour + h_contour < y + box_height):
                slot_empty[i] = False
                break

        color = (0, 255, 0) if slot_empty[i] else (0, 0, 255)
        cv2.rectangle(frame, (x, y), (x + box_width, y + box_height), color, 2)
        cv2.putText(frame, f"{i+1}", (x + 10, y + 30), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

    empty_slots = sum(slot_empty)
    cv2.putText(frame, f"free: {empty_slots}", (7, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 0), 2)

    current_time1 = datetime.now().strftime(" %Y-%m-%d ")
    cv2.putText(frame, f"{current_time1}", (4, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 0), 2)
    current_time2 = datetime.now().strftime(" %H:%M:%S ")
    cv2.putText(frame, f"{current_time2}", (4, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 0), 2)

    return frame

def generate_frames():
    while True:
        success, frame = cap.read()
        if not success:
            break
        detect_yolo(frame)
        frame = detect_contours(frame)
        _, buffer = cv2.imencode('.jpg', frame)
        frame_bytes = base64.b64encode(buffer).decode('utf-8')
        socketio.emit('frame', frame_bytes)
        socketio.sleep(0.1)

@socketio.on('connect')
def handle_connect():
    print('Client connected')
    socketio.start_background_task(target=generate_frames)

@socketio.on('disconnect')
def handle_disconnect():
    print('Client disconnected')

@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    try:
        socketio.run(app, host='0.0.0.0', port=5001, debug=True, use_reloader=False)
    finally:
        cap.release()
