import cv2
import numpy as np
import tkinter as tk
from datetime import datetime

# Global variables
video_path = "video\CAR.mp4"  # Change the path to your video file
cap = cv2.VideoCapture(video_path)
slot_empty = [True] * 10

# Function to detect cars in parking slots
def detect_car(frame):
    global slot_empty

    # Convert image to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Blur the image
    blur = cv2.GaussianBlur(gray, (5, 5), 0)

    # Detect edges
    edges = cv2.Canny(blur, 100, 200)

    # Find contours
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Parking slot parameters
    num_boxes = 6
    box_width = 120
    box_height = 240
    gap = 80
    empty_slots = 0

    for i in range(num_boxes):
        x = i * (box_width + gap) + 50
        y = 360

        if slot_empty[i]:
            cv2.rectangle(frame, (x, y), (x + box_width, y + box_height), (0, 255, 0), 2)
            empty_slots += 1
        else:
            cv2.rectangle(frame, (x, y), (x + box_width, y + box_height), (0, 0, 255), 2)

        # Display sequence number of the box
        cv2.putText(frame, f"{i+1}", (x + 10, y + 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

        # Check if car is detected in the parking slot
        for contour in contours:
            x_contour, y_contour, w_contour, h_contour = cv2.boundingRect(contour)

            if x_contour > x and x_contour + w_contour < x + box_width and y_contour > y and y_contour + h_contour < y + box_height:
                if slot_empty[i]:
                    slot_empty[i] = False
                    empty_slots -= 1
                    break

    # Write text to display the number of empty slots
    cv2.putText(frame, f"Free: {empty_slots}", (50, 70), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 0), 2)
    
    # Write text to display the current date and time
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cv2.putText(frame, f"Date & Time: {current_time}", (50, 120), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

    return frame

# Main function
def main():
    # Create Tkinter window
    root = tk.Tk()
    root.title("Car Park Counter")

    # Create a label to display video
    label = tk.Label(root)
    label.pack()

    # Load the video
    cap = cv2.VideoCapture(video_path)

    if not cap.isOpened():
        print("Error: Unable to open video file.")
        return

    while True:
        ret, frame = cap.read()

        if not ret:
            break

        # Process frame and convert to format suitable for displaying in Tkinter
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame_tk = tk.PhotoImage(data=cv2.imencode('.png', detect_car(frame_rgb))[1].tostring())

        # Update label with new frame
        label.config(image=frame_tk)
        label.image = frame_tk

        root.update()

    cap.release()

    # Close Tkinter window when done
    root.mainloop()

if __name__ == "__main__":
    main()
