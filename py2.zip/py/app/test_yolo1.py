

import cv2
from ultralytics import YOLO
import numpy as np

# Load YOLOv8 model
model = YOLO('yolov8.pt')  # Adjust the model path as needed

# Define parking blocks with coordinates (x, y, width, height)
parking_blocks = [
    (15, 335, 190, 310),   # Block 1
    (220, 335, 190, 310),  # Block 2
    (425, 335, 190, 310),  # Block 3
    (630, 335, 190, 310),  # Block 4
    (835, 335, 190, 310),  # Block 5
    (1040, 335, 190, 310)  # Block 6
]

# Function to check if car is in a block
def is_car_in_block(block, car_bbox):
    bx, by, bw, bh = block
    cx1, cy1, cx2, cy2 = car_bbox
    return (cx1 < bx + bw and cx2 > bx and cy1 < by + bh and cy2 > by)

# Function for detecting objects in video
def test_yolo_detection_video(video_path):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print("Error: Unable to open video file.")
        return

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        # Resize frame for faster processing
        small_frame = cv2.resize(frame, (320, 320))

        # Perform object detection
        results = model(small_frame, conf=0.4, iou=0.3)  # Adjust conf and iou for better accuracy

        # Process results
        occupied_blocks = set()

        for result in results:
            for bbox in result.boxes:
                class_id = int(bbox.cls)
                object_label = model.names[class_id]

                # Convert bounding box coordinates back to the original frame size
                x1, y1, x2, y2 = bbox.xyxy[0].cpu().numpy()
                x1 = int(x1 * (frame.shape[1] / small_frame.shape[1]))
                y1 = int(y1 * (frame.shape[0] / small_frame.shape[0]))
                x2 = int(x2 * (frame.shape[1] / small_frame.shape[1]))
                y2 = int(y2 * (frame.shape[0] / small_frame.shape[0]))
                car_bbox = (x1, y1, x2, y2)

                # Check which block the car is in
                for i, block in enumerate(parking_blocks):
                    if is_car_in_block(block, car_bbox):
                        occupied_blocks.add(i)

                # Display object label on frame
                cv2.putText(frame, object_label, (x1, y1 + 30), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 255), 2, cv2.LINE_AA)

        # Draw parking blocks and display available spaces
        for i, (x, y, w, h) in enumerate(parking_blocks):
            color = (0, 0, 255) if i in occupied_blocks else (0, 255, 0)  # Red if occupied, green if available
            cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)
            cv2.putText(frame, f"P {i + 1}", (x, y - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 2)

        available_spaces = len(parking_blocks) - len(occupied_blocks)
        cv2.putText(frame, f"Available Spaces: {available_spaces}", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)

        # Display frame with detected objects
        cv2.imshow('YOLOv8 Detection', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

# Test YOLOv8 detection on video
test_video_path = r'C:\Users\acer\py\app\video\CAR.mp4'  # Change to your test video path
test_yolo_detection_video(test_video_path)
